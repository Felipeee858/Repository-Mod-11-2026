﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Num1 = new Label();
            Num2 = new Label();
            txtNum2 = new TextBox();
            txtNum1 = new TextBox();
            btnDividir = new Button();
            label1 = new Label();
            lbResultado = new Label();
            errorProvider1 = new ErrorProvider(components);
            btnSoma = new Button();
            btnMulti = new Button();
            btnSub = new Button();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // Num1
            // 
            Num1.AutoSize = true;
            Num1.Location = new Point(72, 83);
            Num1.Name = "Num1";
            Num1.Size = new Size(40, 15);
            Num1.TabIndex = 0;
            Num1.Text = "Num1";
            // 
            // Num2
            // 
            Num2.AutoSize = true;
            Num2.Location = new Point(373, 83);
            Num2.Name = "Num2";
            Num2.Size = new Size(40, 15);
            Num2.TabIndex = 1;
            Num2.Text = "Num2";
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(419, 80);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(100, 23);
            txtNum2.TabIndex = 2;
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(118, 80);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(100, 23);
            txtNum1.TabIndex = 3;
            // 
            // btnDividir
            // 
            btnDividir.Location = new Point(118, 169);
            btnDividir.Name = "btnDividir";
            btnDividir.Size = new Size(100, 31);
            btnDividir.TabIndex = 4;
            btnDividir.Text = "Dividir";
            btnDividir.UseVisualStyleBackColor = true;
            btnDividir.Click += btnDividir_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(58, 340);
            label1.Name = "label1";
            label1.Size = new Size(59, 15);
            label1.TabIndex = 5;
            label1.Text = "Resultado";
            // 
            // lbResultado
            // 
            lbResultado.BorderStyle = BorderStyle.Fixed3D;
            lbResultado.Location = new Point(118, 332);
            lbResultado.Name = "lbResultado";
            lbResultado.Size = new Size(484, 40);
            lbResultado.TabIndex = 6;
            lbResultado.Click += label2_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // btnSoma
            // 
            btnSoma.Location = new Point(419, 169);
            btnSoma.Name = "btnSoma";
            btnSoma.Size = new Size(100, 31);
            btnSoma.TabIndex = 7;
            btnSoma.Text = "Soma";
            btnSoma.UseVisualStyleBackColor = true;
            btnSoma.Click += btnSoma_Click;
            // 
            // btnMulti
            // 
            btnMulti.Location = new Point(118, 240);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(100, 31);
            btnMulti.TabIndex = 8;
            btnMulti.Text = "Multiplicação";
            btnMulti.UseVisualStyleBackColor = true;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnSub
            // 
            btnSub.Location = new Point(419, 240);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(100, 33);
            btnSub.TabIndex = 9;
            btnSub.Text = "Subtração";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            ClientSize = new Size(675, 396);
            Controls.Add(btnSub);
            Controls.Add(btnMulti);
            Controls.Add(btnSoma);
            Controls.Add(lbResultado);
            Controls.Add(label1);
            Controls.Add(btnDividir);
            Controls.Add(txtNum1);
            Controls.Add(txtNum2);
            Controls.Add(Num2);
            Controls.Add(Num1);
            Name = "Form1";
            Text = "Calculadora";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Num1;
        private Label Num2;
        private TextBox txtNum2;
        private TextBox txtNum1;
        private Button btnDividir;
        private Label label1;
        private Label lbResultado;
        private ErrorProvider errorProvider1;
        private Button btnSoma;
        private Button btnSub;
        private Button btnMulti;
    }
}
