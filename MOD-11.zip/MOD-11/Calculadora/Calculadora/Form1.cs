namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void ValidarDivisor(double divisor)
        {
            if (divisor == 0)
            {
                errorProvider1.SetError(txtNum2, "O divisor n�o pode ser zero.");
                throw new DivideByZeroException("Divis�o por zero n�o � permitida.");

            }
        }

        private void LerValores(out double a, out double b)
        {
            errorProvider1.Clear();

            if (string.IsNullOrWhiteSpace(txtNum1.Text))
            {
                errorProvider1.SetError(txtNum1, "Campo obrigat�rio.");
                throw new Exception("O campo n�mero 1 � obrigat�rio.");
            }

            if (string.IsNullOrWhiteSpace(txtNum2.Text))
            {
                errorProvider1.SetError(txtNum2, "Campo obrigat�rio.");
                throw new Exception("O campo n�mero 2 � obrigat�rio.");
            }

            if (!double.TryParse(txtNum1.Text, out a))
            {
                errorProvider1.SetError(txtNum1, "Valor num�rico inv�lido.");
                throw new FormatException("N�mero 1 n�o � um valor num�rico v�lido.");
            }

            if (!double.TryParse(txtNum2.Text, out b))
            {
                errorProvider1.SetError(txtNum2, "Valor num�rico inv�lido.");
                throw new FormatException("N�mero 2 n�o � um valor num�rico v�lido.");
            }
            
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            try
            {
                LerValores(out double a, out double b);
                ValidarDivisor(b);

                lbResultado.Text = "Resultado: " + (a / b);

            }
            catch (FormatException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }
            catch (DivideByZeroException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }
            catch (Exception ex)
            {
                lbResultado.Text = "Erro inesperado: " + ex.Message;
            }
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            try
            {
                LerValores(out double a, out double b);

                lbResultado.Text = "Resultado: " + (a * b);
            }
            catch (FormatException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }


            catch (Exception ex)
            {
                lbResultado.Text = "Erro inesperado: " + ex.Message;
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            try
            {
                LerValores(out double a, out double b);

                lbResultado.Text = "Resultado: " + (a + b);
            }
            catch (FormatException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }


            catch (Exception ex)
            {
                lbResultado.Text = "Erro inesperado: " + ex.Message;
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            try
            {
                LerValores(out double a, out double b);

                lbResultado.Text = "Resultado: " + (a - b);
            }
            catch (FormatException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }


            catch (Exception ex)
            {
                lbResultado.Text = "Erro inesperado: " + ex.Message;
            }
        }
    }
}
