﻿namespace Carro
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtmodelo = new TextBox();
            txtpreco = new TextBox();
            txtano = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnDados = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // txtmodelo
            // 
            txtmodelo.Location = new Point(73, 59);
            txtmodelo.Name = "txtmodelo";
            txtmodelo.Size = new Size(100, 23);
            txtmodelo.TabIndex = 0;
            // 
            // txtpreco
            // 
            txtpreco.Location = new Point(399, 59);
            txtpreco.Name = "txtpreco";
            txtpreco.Size = new Size(100, 23);
            txtpreco.TabIndex = 1;
            // 
            // txtano
            // 
            txtano.Location = new Point(237, 59);
            txtano.Name = "txtano";
            txtano.Size = new Size(100, 23);
            txtano.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 62);
            label1.Name = "label1";
            label1.Size = new Size(48, 15);
            label1.TabIndex = 3;
            label1.Text = "modelo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(193, 62);
            label2.Name = "label2";
            label2.Size = new Size(27, 15);
            label2.TabIndex = 4;
            label2.Text = "ano";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(356, 62);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 5;
            label3.Text = "preço";
            // 
            // btnDados
            // 
            btnDados.Location = new Point(177, 155);
            btnDados.Name = "btnDados";
            btnDados.Size = new Size(169, 63);
            btnDados.TabIndex = 7;
            btnDados.Text = "Dados";
            btnDados.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(524, 241);
            Controls.Add(btnDados);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtano);
            Controls.Add(txtpreco);
            Controls.Add(txtmodelo);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtmodelo;
        private TextBox txtpreco;
        private TextBox txtano;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnDados;
        private ErrorProvider errorProvider1;
    }
}
