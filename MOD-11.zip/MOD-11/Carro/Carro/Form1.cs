namespace Carro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LerValores(out double a, out double b)
        {
            errorProvider1.Clear();

            try
            {


                if (string.IsNullOrWhiteSpace(txtmodelo.Text))
                {
                    errorProvider1.SetError(txtmodelo, "Campo obrigat�rio.");
                    throw new Exception("O campo n�mero 1 � obrigat�rio.");
                }

                if (string.IsNullOrWhiteSpace(txtano.Text))
                {
                    errorProvider1.SetError(txtano, "Campo obrigat�rio.");
                    throw new Exception("O campo n�mero 2 � obrigat�rio.");
                }

                if (string.IsNullOrWhiteSpace(txtpreco.Text))
                {
                    errorProvider1.SetError(txtpreco, "Campo obrigat�rio.");
                    throw new Exception("O campo n�mero 2 � obrigat�rio.");
                }

                if (!double.TryParse(txtano.Text, out a))
                {
                    errorProvider1.SetError(txtano, "Valor num�rico inv�lido.");
                    throw new FormatException("N�mero 1 n�o � um valor num�rico v�lido.");
                }

                if (!double.TryParse(txtpreco.Text, out a))
                {
                    errorProvider1.SetError(txtpreco, "Valor num�rico inv�lido.");
                    throw new FormatException("N�mero 1 n�o � um valor num�rico v�lido.");
                }
            }
            catch (Exception ex) { }


        }
    }
}
