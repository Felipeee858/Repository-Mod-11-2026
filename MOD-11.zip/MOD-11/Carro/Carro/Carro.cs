﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Carro
{
    internal class Carro
    {
        public string Modelo { get; set; }
        public int Ano { get; set; }
        public double Preco { get; set; }

        public Carro(string modelo, int ano, double preco)
        {
            Modelo = modelo;
            Ano = ano;
            Preco = preco;
        }

        
        

        
    }
}
