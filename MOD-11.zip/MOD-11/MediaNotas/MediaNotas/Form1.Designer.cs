﻿namespace MediaNotas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtNota1 = new TextBox();
            txtNota2 = new TextBox();
            btnMedia = new Button();
            lbResultado = new Label();
            errorProvider1 = new ErrorProvider(components);
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // txtNota1
            // 
            txtNota1.Location = new Point(85, 53);
            txtNota1.Name = "txtNota1";
            txtNota1.Size = new Size(113, 23);
            txtNota1.TabIndex = 0;
            txtNota1.TextChanged += txtNota1_TextChanged;
            // 
            // txtNota2
            // 
            txtNota2.Location = new Point(271, 52);
            txtNota2.Name = "txtNota2";
            txtNota2.Size = new Size(113, 23);
            txtNota2.TabIndex = 1;
            // 
            // btnMedia
            // 
            btnMedia.Location = new Point(45, 130);
            btnMedia.Name = "btnMedia";
            btnMedia.Size = new Size(153, 31);
            btnMedia.TabIndex = 2;
            btnMedia.Text = "Média";
            btnMedia.UseVisualStyleBackColor = true;
            btnMedia.Click += btnMedia_Click;
            // 
            // lbResultado
            // 
            lbResultado.ForeColor = Color.Black;
            lbResultado.Location = new Point(236, 132);
            lbResultado.Name = "lbResultado";
            lbResultado.Size = new Size(221, 31);
            lbResultado.TabIndex = 3;
            lbResultado.Text = "Resultado: ";
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // label1
            // 
            label1.ForeColor = Color.Black;
            label1.Location = new Point(31, 56);
            label1.Name = "label1";
            label1.Size = new Size(48, 28);
            label1.TabIndex = 4;
            label1.Text = "Nota 1";
            // 
            // label2
            // 
            label2.ForeColor = Color.Black;
            label2.Location = new Point(215, 55);
            label2.Name = "label2";
            label2.Size = new Size(50, 25);
            label2.TabIndex = 5;
            label2.Text = "Nota 2";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(464, 172);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lbResultado);
            Controls.Add(btnMedia);
            Controls.Add(txtNota2);
            Controls.Add(txtNota1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNota1;
        private TextBox txtNota2;
        private Button btnMedia;
        private Label lbResultado;
        private ErrorProvider errorProvider1;
        private Label label2;
        private Label label1;
    }
}
