namespace MediaNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {

            try
            {
                LerValores(out double a, out double b);

                lbResultado.Text = "Resultado: " + (a + b) / 2;

            }
            catch (FormatException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }
            catch (DivideByZeroException ex)
            {
                lbResultado.Text = "Erro: " + ex.Message;
            }
            catch (Exception ex)
            {
                lbResultado.Text = "Erro inesperado: " + ex.Message;
            }
        }



        private void LerValores(out double a, out double b)
        {
            errorProvider1.Clear();
            if (string.IsNullOrWhiteSpace(txtNota1.Text))
            {
                errorProvider1.SetError(txtNota1, "Campo obrigat�rio.");
                throw new Exception("O campo n�mero 1 � obrigat�rio.");
            }

            if (string.IsNullOrWhiteSpace(txtNota2.Text))
            {
                errorProvider1.SetError(txtNota2, "Campo obrigat�rio.");
                throw new Exception("O campo n�mero 2 � obrigat�rio.");
            }

            if (!double.TryParse(txtNota1.Text, out a))
            {
                errorProvider1.SetError(txtNota1, "Valor num�rico inv�lido.");
                throw new FormatException("N�mero 1 n�o � um valor num�rico v�lido.");
            }

            if (!double.TryParse(txtNota2.Text, out b))
            {
                errorProvider1.SetError(txtNota2, "Valor num�rico inv�lido.");
                throw new FormatException("N�mero 2 n�o � um valor num�rico v�lido.");
            }

            


        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNota1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
