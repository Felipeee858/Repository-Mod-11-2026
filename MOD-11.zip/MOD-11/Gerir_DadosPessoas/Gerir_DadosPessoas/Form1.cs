using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Text.Json;

namespace Gerir_DadosPessoas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //Guardar em ficheiro TXT
            try
            {
                Pessoa p = new Pessoa(int.Parse(txtId.Text), txtNome.Text,
                    int.Parse(txtIdade.Text), txtEmail.Text);

                using (StreamWriter sw = new StreamWriter("pessoas.txt", true))
                {
                    sw.WriteLine(p.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao guardar: " + ex.Message);
            }
        }

        private void btnLerT_Click(object sender, EventArgs e)
        {

            lstPessoas.Items.Clear();

            try
            {
                using (StreamReader sr = new StreamReader("pessoas.txt"))
                {
                    string linha;

                    //Ler linha a linha
                    while ((linha = sr.ReadLine()) != null)
                    {
                        //Separar campos;
                        string[] dados = linha.Split(";");

                        Pessoa p = new Pessoa(int.Parse(dados[0]), dados[1], int.Parse(dados[2]), dados[3]);

                        lstPessoas.Items.Add(p.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao ler ficheiro: " + ex.Message);
            }
        }

        private void btnGuardarJ_Click(object sender, EventArgs e)
        {

            try
            {
                Pessoa p = new Pessoa(int.Parse(txtId.Text), txtNome.Text, int.Parse(txtIdade.Text), txtEmail.Text);

                List<Pessoa> pessoas = new List<Pessoa>();

                //Se o ficheiro j� existe, ler dados anteriores
                if (File.Exists("pessoas.json"))
                {
                    using (FileStream fs = new FileStream("pessoas.json", FileMode.Open))
                    {
                        pessoas = JsonSerializer.Deserialize<List<Pessoa>>(fs);
                    }
                }
                pessoas.Add(p);

                //Guardar lista atualizada
                using (FileStream fs = new FileStream("pessoas.json", FileMode.Create))
                {
                    JsonSerializer.Serialize(fs, pessoas, new JsonSerializerOptions { WriteIndented = true });
                }

                MessageBox.Show("Pessoa guardada com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }

        private void btnLerJ_Click(object sender, EventArgs e)
        {
            lstPessoas.Items.Clear();

            try
            {
                if (!File.Exists("pessoas.json"))
                {
                    MessageBox.Show("Nenhum ficheiro encontrado. ");
                    return;

                }
                using (FileStream fs = new FileStream("pessoas.json", FileMode.Open))
                {
                    List<Pessoa> pessoas = JsonSerializer.Deserialize<List<Pessoa>>(fs);

                    foreach (Pessoa p in pessoas)
                    {
                        lstPessoas.Items.Add(p.ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CarregarJson();
        }

        private void CarregarJson()
        {
            lstPessoas.Items.Clear();

            if (!File.Exists("pessoas.json"))
                return;
            try
            {
                using (FileStream fs = new FileStream("pessoas.json,", FileMode.Open))
                {
                    List<Pessoa> pessoas = JsonSerializer.Deserialize<List<Pessoa>>(fs);
                    foreach (Pessoa p in pessoas)
                    {
                        lstPessoas.Items.Add(p.ToString());
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro ao carregar ficheiro JSON: " + ex.Message);
            }
        }
        private void btnM_Click(object sender, EventArgs e)
        {
            lstPessoas.Items.Clear();

            using (StreamReader sr = new StreamReader("pessoas.txt"))
            {
                string linha;
                while ((linha = sr.ReadLine()) != null)
                {
                    string[] dados = linha.Split(";");
                    int idade = int.Parse(dados[2]);

                    if (idade >= 18)
                    {
                        Pessoa p = new Pessoa(
                            int.Parse(dados[0]),
                            dados[1],
                            idade,
                            dados[3]
                            );

                        lstPessoas.Items.Add(p.ToString());
                    }


                }
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            lstPessoas.Items.Clear();

            List<Pessoa> listaPessoas = new List<Pessoa>();
            try
            {
                using (StreamReader sr = new StreamReader("pessoas.txt"))
                {
                    string linha;
                    while ((linha = sr.ReadLine()) != null)
                    {
                        string[] dados = linha.Split(";");

                        Pessoa p = new Pessoa(
                            int.Parse(dados[0]),
                            dados[1],
                            int.Parse(dados[2]),
                            dados[3]);

                        listaPessoas.Add(p);
                        lstPessoas.Items.Add(p.ToString());
                    }
                }
                    using (FileStream fs = new FileStream("pessoas.json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, listaPessoas, new JsonSerializerOptions { WriteIndented = true });
                    }
                    MessageBox.Show("Ficheiro convertido");
            }

            catch (Exception ex)
            {
                MessageBox.Show("Erro ao converter" + ex.Message);
            }
            
        }
    }
}


