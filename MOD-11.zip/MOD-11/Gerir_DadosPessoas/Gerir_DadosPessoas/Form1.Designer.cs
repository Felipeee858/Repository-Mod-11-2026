﻿namespace Gerir_DadosPessoas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtId = new TextBox();
            lstPessoas = new ListBox();
            btnLerT = new Button();
            btnGuardarT = new Button();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            txtIdade = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnLerJ = new Button();
            btnGuardarJ = new Button();
            btnM = new Button();
            btnConvert = new Button();
            SuspendLayout();
            // 
            // txtId
            // 
            txtId.Location = new Point(70, 31);
            txtId.Name = "txtId";
            txtId.Size = new Size(100, 23);
            txtId.TabIndex = 0;
            // 
            // lstPessoas
            // 
            lstPessoas.FormattingEnabled = true;
            lstPessoas.ItemHeight = 15;
            lstPessoas.Location = new Point(26, 162);
            lstPessoas.Name = "lstPessoas";
            lstPessoas.Size = new Size(420, 124);
            lstPessoas.TabIndex = 1;
            // 
            // btnLerT
            // 
            btnLerT.Location = new Point(116, 374);
            btnLerT.Name = "btnLerT";
            btnLerT.Size = new Size(82, 34);
            btnLerT.TabIndex = 2;
            btnLerT.Text = "Ler TXT";
            btnLerT.UseVisualStyleBackColor = true;
            btnLerT.Click += btnLerT_Click;
            // 
            // btnGuardarT
            // 
            btnGuardarT.Location = new Point(26, 374);
            btnGuardarT.Name = "btnGuardarT";
            btnGuardarT.Size = new Size(84, 34);
            btnGuardarT.TabIndex = 3;
            btnGuardarT.Text = "Guardar TXT";
            btnGuardarT.UseVisualStyleBackColor = true;
            btnGuardarT.Click += btnGuardar_Click;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(346, 105);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(346, 35);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 5;
            // 
            // txtIdade
            // 
            txtIdade.Location = new Point(70, 105);
            txtIdade.Name = "txtIdade";
            txtIdade.Size = new Size(100, 23);
            txtIdade.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(26, 35);
            label1.Name = "label1";
            label1.Size = new Size(17, 15);
            label1.TabIndex = 7;
            label1.Text = "Id";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(26, 108);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 8;
            label2.Text = "Idade";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(285, 38);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 9;
            label3.Text = "Nome";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(285, 108);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 10;
            label4.Text = "Email";
            // 
            // btnLerJ
            // 
            btnLerJ.Location = new Point(364, 374);
            btnLerJ.Name = "btnLerJ";
            btnLerJ.Size = new Size(82, 34);
            btnLerJ.TabIndex = 11;
            btnLerJ.Text = "Ler JSON";
            btnLerJ.UseVisualStyleBackColor = true;
            btnLerJ.Click += btnLerJ_Click;
            // 
            // btnGuardarJ
            // 
            btnGuardarJ.Location = new Point(261, 374);
            btnGuardarJ.Name = "btnGuardarJ";
            btnGuardarJ.Size = new Size(92, 34);
            btnGuardarJ.TabIndex = 12;
            btnGuardarJ.Text = "Guardar JSON";
            btnGuardarJ.UseVisualStyleBackColor = true;
            btnGuardarJ.Click += btnGuardarJ_Click;
            // 
            // btnM
            // 
            btnM.Location = new Point(66, 414);
            btnM.Name = "btnM";
            btnM.Size = new Size(104, 23);
            btnM.TabIndex = 13;
            btnM.Text = "Maiores de 18";
            btnM.UseVisualStyleBackColor = true;
            btnM.Click += btnM_Click;
            // 
            // btnConvert
            // 
            btnConvert.Location = new Point(285, 414);
            btnConvert.Name = "btnConvert";
            btnConvert.Size = new Size(143, 23);
            btnConvert.TabIndex = 14;
            btnConvert.Text = "Converter TXT em JSON";
            btnConvert.UseVisualStyleBackColor = true;
            btnConvert.Click += btnConvert_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(471, 444);
            Controls.Add(btnConvert);
            Controls.Add(btnM);
            Controls.Add(btnGuardarJ);
            Controls.Add(btnLerJ);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtIdade);
            Controls.Add(txtNome);
            Controls.Add(txtEmail);
            Controls.Add(btnGuardarT);
            Controls.Add(btnLerT);
            Controls.Add(lstPessoas);
            Controls.Add(txtId);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtId;
        private ListBox lstPessoas;
        private Button btnLerT;
        private Button btnGuardarT;
        private TextBox txtEmail;
        private TextBox txtNome;
        private TextBox txtIdade;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnLerJ;
        private Button btnGuardarJ;
        private Button btnM;
        private Button btnConvert;
    }
}
